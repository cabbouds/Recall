G6_ui <- function(id){
  ns <- NS(id)
  tagList(
    #h4("Whirpool"),
    sidebarLayout(
      sidebarPanel( width = 3,
                    img(src ="Whirpool.png",height=72,width=72),
                    sliderInput(ns("date_range"), 
                                "Date Range:", 
                                min =  min(Acum_II$date[Acum_II$Brand=='Whirpool']), 
                                max = max(Acum_II$date[Acum_II$Brand=='Whirpool']), 
                                value = c(min(Acum_II$date[Acum_II$Brand=='Whirpool']),
                                          max(Acum_II$date[Acum_II$Brand=='Whirpool'])
                                ),
                                timeFormat = "%F",
                                step = 1),
                    
                    sliderInput(inputId =  ns("Bubble_Size"), 
                                label = "Bubble Size:", 
                                value = c(2,13), min = 1, max = 25, step = 1 
                    ),
                    checkboxInput("Net_Score", "Net Score Function", TRUE),
                    checkboxInput("Freq_Score", "Frequency by Score", TRUE),
                    checkboxInput("Proba_Review", "Probability of a bad Review", TRUE)
      ),
      mainPanel(
        
        textOutput(ns('text')),
        conditionalPanel("input.Net_Score == TRUE",
                         plotOutput(ns('g1'), height = 250)),
        plotOutput(ns('g2'), height = 250),
        plotOutput(ns('g3'), height = 250)
        
      )
      
    ) #Layout
    
  )}