G3_ui <- function(id){
  ns <- NS(id)
  tagList(
    #h4("BlueBell"),
    sidebarLayout(
      sidebarPanel( width = 0,
                    img(src ="BlueBell.png", height = 70, width = 100),
                    sliderInput(ns("date_range"), 
                                "Date Range:", 
                                min =  min(Acum_II$date[Acum_II$Brand=='BlueBell']), 
                                max = max(Acum_II$date[Acum_II$Brand=='BlueBell']), 
                                value = c(min(Acum_II$date[Acum_II$Brand=='BlueBell']),
                                          max(Acum_II$date[Acum_II$Brand=='BlueBell'])
                                ),
                                timeFormat = "%F",
                                step = 1),
                    
                    sliderInput(inputId =  ns("Bubble_Size"), 
                                label = "Bubble Size:", 
                                value = c(2,14), min = 1, max = 25, step = 1, width = 800
                    )
                    #, checkboxInput("Net_Score", "Net Score Function", TRUE),
                    # checkboxInput("Freq_Score", "Frequency by Score", TRUE),
                    # checkboxInput("Proba_Review", "Probability of a bad Review", TRUE)
      ),
      mainPanel(
        
        textOutput(ns('text')),
        conditionalPanel("input.Net_Score == TRUE",
                         plotOutput(ns('g1'), height = 230, width = 1250)),
        plotOutput(ns('g2'), height = 230, width = 1250),
        plotOutput(ns('g3'), height = 230, width = 1250)
        
      )
      
    ) #Layout
    
  )}
