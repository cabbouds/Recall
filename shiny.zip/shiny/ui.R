
shinyUI(fluidPage(#theme = "bootstrap.css",
  
  tabsetPanel(
    selected = "Note7", type = "pills",
    
    tabPanel("Note7", G1_ui("Note7"))
    ,
    tabPanel("Toyota", G2_ui("Toyota"))
    ,
    tabPanel("BlueBell", G3_ui("BlueBell"))
    ,
    tabPanel("Mars", G4_ui("Mars"))
    ,
    tabPanel("Hoverboard", G5_ui("Hoverboard"))
    ,
    tabPanel("Whirpool", G6_ui("Whirpool"))
    
  )
  
  )
)
