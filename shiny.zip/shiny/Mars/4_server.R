Mars_server <- function(input, output, session) {
  
  #output$text <-renderText(paste('date_range:',input$Bubble_Size ))
  # filter  
  Acum_I <- Acum_I %>% filter(.,Brand == "Mars")
  Acum_II <- Acum_II %>% filter(.,Brand == "Mars")
  # aux
  N_global = length(Acum_I$score) # N = Número de Observaciones
  NP_global = sum(Acum_I$score<0) # NP = Número de Observaciones Defectuosas
  NQ_global = sum(Acum_I$score>0) # NP = Número de Observaciones Positivas
  P = NP_global / N_global
  P2 = NP_global / (NP_global - NQ_global)
  
  ####### Graph 1 #######################################################################  
  output$g1 <- renderPlot({
    
    Acum_II <- Acum_II %>% filter(.,date >= input$date_range[1],date <= input$date_range[2])
    
    g1_Mars <- ggplot(Acum_II, aes(y = Score_Net, x = date)) + 
      geom_line(aes(colour = Score_Net),size=1.5)  + 
      labs(title = "Mars") + 
      scale_x_date(breaks = pretty_breaks(75), date_labels =  "%d-%m-%y",
      ) +
      xlim(c(
        min(Acum_II$date[Acum_II$Brand=='Mars']), # sale sobrando, ya se hizo reactive desde la data
        max(Acum_II$date[Acum_II$Brand=='Mars'])
      )) + 
      ylab("Net Score by Day") +
      theme_minimal() +
      scale_colour_gradient2(low ="tomato3",mid = "lightgoldenrod1", high = "forestgreen") + #scale_colour_gradient2()+
      theme(legend.position="none",
            plot.title = element_text(size = 14, face = "bold", vjust = 2, color = 'black', lineheight = 0.8),
            axis.title.x = element_blank(), 
            #axis.title.x = element_text(size = 14),
            axis.title.y = element_text(size = 14),
            axis.text.y = element_text(size = 11, face = "bold", color = 'black'),
            axis.text.x = element_text(size = 10, face = "bold", color = 'black', angle = 80, hjust = 1)
      ) +
      geom_label_repel(data = Acum_II[Acum_II$Who=="Mars",],
                       aes(y = p, label = substr(Short, 1, 9)),
                       size = 4,
                       max.iter = 100)
    
    print(g1_Mars)
  })
  
  ####### Graph 2 #######################################################################  
  
  output$g2 <- renderPlot({
    
    #filter
    Acum_I <- Acum_I %>% filter(.,date >= input$date_range[1],date <= input$date_range[2])
    
    g2_Mars <- ggplot(Acum_I, aes(date,score)) 
    g2_Mars <- g2_Mars + geom_count(aes(colour = score, alpha =3), show.legend = F) + #,col = "tomato3"
      theme_minimal() + #$theme_bw()+
      scale_colour_gradient2(low ="tomato3",mid = "lightgoldenrod1", high = "forestgreen") +
      scale_x_date(breaks = pretty_breaks(75), date_labels =  "") +
      coord_trans(y="mi_log") +  # mi_log(x) = sign(x)*log(abs(x)+1)
      
      theme(axis.title.x = element_blank(), 
            axis.text.x = element_blank(),
            axis.title.y = element_text(size = 14),
            axis.text.y = element_text(size = 11, face = "bold", color = 'black')
            #,axis.text.x = element_text(angle = 45, hjust = 1,size=11)
      ) +
      scale_size(range = c(input$Bubble_Size[1], input$Bubble_Size[2])) + # parameter...
      labs(y="Freq. by Score&Day")
    
    print(g2_Mars)
  })
  
  ####### Graph 3 #######################################################################
  cols <- c("#ce472e", "#f05336", "#ffd73e", "#eec73a", "#4ab04a") # color palette
  
  output$g3 <- renderPlot({
    
    burned <- function(p,upper){ifelse(p < upper,0,1)}
    Acum_II <- Acum_II %>% filter(.,date >= input$date_range[1],date <= input$date_range[2])
    
    g3_Mars <- ggplot(Acum_II, aes(x = date)) +
      theme_minimal() +
      scale_color_gradientn(colors = rev(cols), limits = c(0, 1), na.value="red",
                            breaks = seq(0, 1, by = 1/4),
                            labels = c("0", round(1/4*4, 1), round(1/4*3, 1), round(1/4*2, 1), round(1/4*1, 1)),
                            guide = guide_colourbar(ticks = T, nbin = 50, barheight = .5, label = T, barwidth = 10)) +
      geom_point(aes(y = p, color = p + burned(p,upper) , alpha = 1, size = 4)) + # {ifelse(p < upper,0,1)}
      geom_step(aes(y = upper)) + #, color = upper
      geom_hline(yintercept = P, color = "#f05336", size = 1.5, alpha = 0.6, linetype = "longdash") +
      geom_label_repel(data = Acum_II[!is.na(Acum_II$Short),],
                       aes(y = p, label = round(p, 2)),
                       fontface = 'bold',
                       size = 2.5,
                       max.iter = 100) +
      scale_x_date(breaks = pretty_breaks(50), date_labels =  "%d-%b-%y") +
      ylab("Freq. of Bad Reviews")+ 
      theme(legend.position="none", #legend.position = 'bottom', #legend.direction = "horizontal",
            plot.title = element_text(size = 14, face = "bold", vjust = 2, color = 'black', lineheight = 0.8),
            axis.title.x = element_blank(),
            axis.title.y = element_text(size = 14),
            axis.text.y = element_text(size = 11, face = "bold", color = 'black'),
            axis.text.x = element_text(size =11, face = "bold", color = 'black',angle = 80, hjust = 1)
      ) 
    
    print(g3_Mars)
  }) 
  
} ## EOF

#runApp('shiny')