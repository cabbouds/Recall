library(shiny)

ui <- shinyUI(fluidPage(
  
  sliderInput("date_range", 
              "Purchase Date Range:", 
              min = as.Date("2015-01-20"), max = Sys.Date(), 
              value = c(as.Date("2016-02-25"), Sys.Date()),
              timeFormat = "%F",
              step = 1
  ),
  mainPanel(
    tableOutput( "view" )
  )
)
)


server <- function(input, output) {
  
  ## note: y formatted as Date'
  df <- data.frame(x = c("a", "a", "b", "b", "b"), 
                   y = as.Date(c("2016-01-01", "2016-02-04", "2016-03-05", "2016-01-01", "2016-04-06")))
  
  output$view <- renderTable({
    
    df[df$y >= input$date_range[1] & df$y <= input$date_range[2], ]
    
  })
}

shinyApp(ui, server)