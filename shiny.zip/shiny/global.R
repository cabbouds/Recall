# load package and data
library(tidyverse)
library(ggplot2)
library(reshape)
library(scales)
library(grid)
library(gridExtra)
library(lubridate)
library(ggrepel)
library(shiny)
library(shinyjs)

Acum_I <-readRDS("./0-data/Acum_I.rds")
Acum_II <-readRDS("./0-data/Acum_II.rds")

# functions
source("./0-function/mi_log_trans.R")

# Note7
source("./Note7/1_ui.R")
source("./Note7/1_server.R")
# Toyota
source("./Toyota/2_ui.R")
source("./Toyota/2_server.R")
# Blue Bell
source("./BlueBell/3_ui.R")
source("./BlueBell/3_server.R")
# Mars
source("./Mars/4_ui.R")
source("./Mars/4_server.R")
# Hoverboard
source("./Hoverboard/5_ui.R")
source("./Hoverboard/5_server.R")
# Whirpool
source("./Whirpool/6_ui.R")
source("./Whirpool/6_server.R")