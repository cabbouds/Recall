library(shiny)

shinyServer(function(input, output, session) {

  callModule(Note7_server,"Note7")
  callModule(Toyota_server,"Toyota")
  callModule(BlueBell_server,"BlueBell")
  callModule(Mars_server,"Mars")
  callModule(Hoverboard_server,"Hoverboard")
  callModule(Whirpool_server,"Whirpool")
})
